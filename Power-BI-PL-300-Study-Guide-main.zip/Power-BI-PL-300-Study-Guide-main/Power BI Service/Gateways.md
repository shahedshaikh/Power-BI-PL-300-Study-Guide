# [Gateways](https://docs.microsoft.com/en-us/power-bi/connect-data/service-gateway-deployment-guidance)

## [Single Sign-On](https://docs.microsoft.com/en-us/power-bi/connect-data/service-gateway-sso-overview)

# [Smart Narratives](https://docs.microsoft.com/en-us/power-bi/visuals/power-bi-visualization-smart-narrative?WT.mc_id=DP-MVP-5003635)

`Notice: This is a personal study file. It assumes a certain familiarity with the topic and therefore DOES NOT contain everything about this topic. The author created this to track more technical gotchas that might appear in the PL-300 exam.`

`Note: Not currently required by the PL-300`


